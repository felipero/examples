int j;
